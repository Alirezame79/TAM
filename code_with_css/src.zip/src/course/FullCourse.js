
export default function FullCourse() {
    return (
        <div>

        </div>
    )
}