import { createAction } from "@reduxjs/toolkit"

const reset = createAction("app/reset")

export default reset;