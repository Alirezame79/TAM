import classes from './Login.module.css';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { Checkbox, FormControlLabel } from '@mui/material';
import { blue, pink } from "@mui/material/colors";
import { useEffect, useRef } from 'react';
import axios from 'axios';
import uniLogo from './navbar-logo.png'
import loginImg from './imglog_auto_x2.jpg';

export default function Login() {
    const username = useRef("");
    const password = useRef("");

    function loginClicked() {
        let user = {
            username: username.current.value,
            password: password.current.value
        }

        console.log(user)

        fetch('http://127.0.0.1:8000/login', {
            method: 'POST',
            body: JSON.stringify(user),
            headers: {
                'Content-Type': 'application/json'
            }
        }).then((response) => {
            console.log(response)
            return response.json;
        }).then((data) => {
            console.log(data);
        });

        // axios.post('http://127.0.0.1:8000/login/', { user })
        //     .then(function (response) {
        //         console.log(response);
        //     })

        // fetch('http://127.0.0.1:8000/login/' + user).then((response) => {
        //     console.log("1 ", response);
        //     return response.json();
        // }).then((data) => {
        //     console.log("2 ", data);
        // })
    }
    const backImg ={
        backgroundImage : `url(${loginImg})`
    }

    return (
        <div className={classes.container}>
            <div className={classes.header}>
            <img src={uniLogo} alt="guilan uni logo" className={classes.uniLable}/>
                <h2 className={classes.tamLable}>سامانه تام</h2>
               
                <img src='image.jpg' alt="TAM logo" />
            </div>
            <div className={classes.img} style={backImg}>
                {/* <img src={loginImg} alt="login" className={classes.backgroundImage} /> */}
            </div>
            <div className={classes.loginBox}>
                <label htmlFor="username" className={classes.labelText}>نام کاربری</label>
                <Input innerRef={username} id="username"  className={classes.myInputs}/>
                <label htmlFor="password" type='password' className={classes.labelText}>رمز عبور</label>
                <Input innerRef={password} id="password" className={classes.myInputs}/>
                <Button click={loginClicked} loginBtn>ورود</Button>
            </div>

            <div className={classes.triangleContainer} >
            <div className={classes.triangleUp} ></div>
            <div className={classes.textUp} >نام کاربری شما همان شماره دانشجویی تان است</div>
        </div>
        <div className={classes.triangleContainer} >
            <div className={classes.triangleDown} ></div>
            <div className={classes.textDown} > اکر اولین بار هست که وارد سامانه میشوید و یا رمز عبور خود را تغییر ندادید رمر عبور شما کد ملی تان می باشد</div>
        </div>
            <div className={classes.footer}> 
            <div className={classes.box}><p className={classes.footerText}>هدف تام ؟</p></div>
            <div className={classes.box}><p className={classes.footerText}>چرا تام ؟</p></div>
            </div>
        </div>
       
    )
}